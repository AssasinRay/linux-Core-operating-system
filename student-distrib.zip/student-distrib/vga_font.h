#ifndef VGA_FONT_H
#define VGA_FONT_H

#include "types.h"

uint8_t set_font(uint16_t character);
void write_font();

#endif
