#ifndef _SYSCALL_WRAPPER_H
#define _SYSCALL_WRAPPER_H
/*
#include "syscall.h"
#include "lib.h"
#include "x86_desc.h"
#include "types.h"
#include "i8259.h"
#include "multiboot.h"
#include "debug.h"
*/
extern void syscall_wrapper();

#endif











