#ifndef _PIT_H
#define _PIT_H

#include "types.h"

void init_pit(int32_t frequency);
void play_sound(uint32_t nFrequence);
void nosound() ;
void music();
// void nosound();
// void beep() ;

#endif







